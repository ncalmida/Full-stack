let n1 = 100;
let n2 = 100;
let r = n1 + n2;

console.log(r)