let numero = Math.floor(Math.random() * 100)

console.log(Math.random())